import React from 'react';
import ReactDOM from 'react-dom';

const color1 = React.createElement('li', {}, 'Black');
const color2 = React.createElement('li', {}, 'Red');
const color3 = React.createElement('li', {}, 'Grey');

const artist1 = React.createElement('li', {}, 'Pierce The Veil');
const artist2 = React.createElement('li', {}, 'Our Last Night');
const artist3 = React.createElement('li', {}, 'Four Year Strong');

const food1 = React.createElement('li', {}, 'Pizza');
const food2 = React.createElement('li', {}, 'Mexican Food');
const food3 = React.createElement('li', {}, 'Chinese Food');

const website1 = React.createElement(
  'li',
  {},
  React.createElement('a', { href: 'https://www.youtube.com' }, 'www.youtube.com')
);
const website2 = React.createElement(
  'li',
  {},
  React.createElement('a', { href: 'https://www.crunchyroll.com' }, 'www.crunchyroll.com')
);
const website3 = React.createElement(
  'li',
  {},
  React.createElement('a', { href: 'https://www.spotify.com' }, 'www.spotify.com')
);

ReactDOM.render(
  React.createElement(
    'div',
    {},
    React.createElement('h1', {}, 'My Favorite Things'),
    React.createElement(
      'ul',
      {},
      React.createElement(
        'li',
        {},
        'Favorite Colors',
        React.createElement('ol', {}, color1, color2, color3)
      ),
      React.createElement(
        'li',
        {},
        'Favorite Music',
        React.createElement('ol', {}, artist1, artist2, artist3)
      ),
      React.createElement(
        'li',
        {},
        'Favorite Food',
        React.createElement('ol', {}, food1, food2, food3)
      ),
      React.createElement(
        'li',
        {},
        'Favorite Websites',
        React.createElement('ol', {}, website1, website2, website3)
      )
    )
  ),
  document.getElementById('root')
);